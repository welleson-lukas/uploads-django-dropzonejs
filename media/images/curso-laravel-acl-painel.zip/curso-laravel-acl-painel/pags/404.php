<div class="container text-center">
	<h1>404</h1>
	<img src="imgs/404-laramusic.png" alt="404">
</div>