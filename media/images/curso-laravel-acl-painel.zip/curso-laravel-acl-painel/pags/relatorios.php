<div class="container">
	<h1 class="title">
		Listagem dos usuários
	</h1>

	<table class="table table-hover">
	  <tr>
	  	<th>Nome</th>
	  	<th>Email</th>
	  	<th>Idade</th>
	  	<th width="100px">Ações</th>
	  </tr>

	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	  <tr>
	  	<td>Carlos Ferreira</td>
	  	<td>carlos@especializati.com.br</td>
	  	<td>90</td>
	  	<td>
	  		<a href="forms" class="edit">
	  			<i class="fa fa-pencil-square-o"></i>
	  		</a>
	  		<a href="" class="delete">
	  			<i class="fa fa-trash"></i>
	  		</a>
	  	</td>
	  </tr>
	</table>


	<nav>
		  <ul class="pagination">
		    <li>
		      <a href="#" aria-label="Previous">
		        <span aria-hidden="true">&laquo;</span>
		      </a>
		    </li>
		    <li><a href="#">1</a></li>
		    <li><a href="#">2</a></li>
		    <li><a href="#">3</a></li>
		    <li><a href="#">4</a></li>
		    <li><a href="#">5</a></li>
		    <li>
		      <a href="#" aria-label="Next">
		        <span aria-hidden="true">&raquo;</span>
		      </a>
		    </li>
		  </ul>
		</nav>
</div>