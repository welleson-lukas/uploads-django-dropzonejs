<div class="container">
	<h1 class="title">
		Gestão Usuário	
	</h1>

	<form class="form">
		<div class="form-group">
			<input type="text" name="nome" placeholder="Insira o Nome" class="form-control">
		</div>
		<div class="form-group">
			<input type="text" name="email" placeholder="Insira o email" class="form-control">
		</div>
		<div class="form-group">
			<input type="text" name="idade" placeholder="Insira o idade" class="form-control">
		</div>
		<div class="form-group">
			<input type="text" name="telefone" placeholder="Insira o telefone" class="form-control">
		</div>
		<div class="form-group">
			<input type="password" name="senha" placeholder="Insira o senha" class="form-control">
		</div>
		<div class="form-group">
			<input type="confirm-password" name="confirm senha" placeholder="Insira o confirm senha" class="form-control">
		</div>

		<div class="form-group">
			<input type="submit" name="enviar" value="Enviar" class="btn btn-success">
		</div>
	</form>
</div>